def multplicator_table(num):
    for i in range(0, 11):
        print(num, 'x', i, '=', num*i)