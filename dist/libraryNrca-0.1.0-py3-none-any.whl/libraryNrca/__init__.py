from . bisextil_year import bisextil_year
from . multplicator_table import multplicator_table

__all__=[
    'bisextil_year',
    'multplicator_table'
]